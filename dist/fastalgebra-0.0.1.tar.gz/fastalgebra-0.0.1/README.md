# fastalgebra
Currently in development!
## Installation
```
pip install .
```
requires a C compiler
## Usage
```python
import fastalgebra
expr = fastalgebra.Expression("(1+2)(3+a)/15b-c")
print(expr.stringify())
# (1+2)*(3+a)/(15*b)-c
```
more stuff coming soon

